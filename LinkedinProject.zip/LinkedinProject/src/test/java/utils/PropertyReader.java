//package utils;
// 
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.Properties;
// 
//public class PropertyReader {
//    private static Properties properties = new Properties();
// 
//    public static void loadProperties(String filePath) throws IOException {
//        FileInputStream fis = new FileInputStream(filePath);
//        properties.load(fis);
//    }
// 
//    public static String getProperty(String key) {
//        return properties.getProperty(key);
//    }
//}