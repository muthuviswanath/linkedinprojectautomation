//package pages;
//
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import java.time.Duration;
//
//public class TC002 {
//
//    private WebDriver driver;
//    private WebDriverWait wait;
//
//    @FindBy(xpath = "//span[text()='Jobs']/ancestor::a")
//    private WebElement jobModule;
//
//    @FindBy(xpath = "//input[contains(@id,'jobs') and contains(@aria-label,'skill')]")
//    private WebElement jobSearchBar;
//
//    @FindBy(xpath = "//input[contains(@id,'location') and contains(@aria-label,'City')]")
//    private WebElement locationSearchBar;
//
//    public TC002(WebDriver driver) {
//        this.driver = driver;
//        this.wait = new WebDriverWait(driver, Duration.ofSeconds(40)); // Increased the wait time to 40 seconds
//        PageFactory.initElements(driver, this);
//    }
//
//    // Method to click on the Job Module first
//    public void job() {
//        try {
//            // Wait for the element to be visible and clickable
//            wait.until(ExpectedConditions.visibilityOf(jobModule));
//            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
//            jobModule.click(); // Click the job module first
//            System.out.println("Job Module clicked successfully.");
//        } catch (Exception e) {
//            System.out.println("Element not clickable using standard method.");
//            e.printStackTrace();
//        }
//    }
//
//    // Perform the negative test case after the job module is clicked
//    public void performNegativeTest() {
//        job();  // Ensure the job module is clicked first
//        
//        // Clear and fill in the job search bar using JavaScriptExecutor
//        try {
//            JavascriptExecutor js = (JavascriptExecutor) driver;
//            wait.until(ExpectedConditions.visibilityOf(jobSearchBar));
//            js.executeScript("arguments[0].value='';", jobSearchBar); // Clear the search bar
//            jobSearchBar.sendKeys("Hell"); // Input some invalid data for the negative test case
//            System.out.println("Entered job search keyword.");
//
//            // Clear and fill in the location search bar
//            wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
//            locationSearchBar.clear(); // Clear the location field
//            locationSearchBar.sendKeys(" ,Karnataka,Bengaluru"); // Provide an invalid location
//            System.out.println("Entered location keyword.");
//            Actions actions = new Actions(driver);
//            wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
//            Thread.sleep(2000);
//            actions.moveToElement(locationSearchBar).moveByOffset(50, 100).click().perform();
//
//        } catch (Exception e) {
//            System.out.println("Error while performing negative test case.");
//            e.printStackTrace();
//        }
//    }
//}




package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utils.Screenshots;

import java.time.Duration;

public class TC002 {

    private WebDriver driver;
    private WebDriverWait wait;

    @FindBy(xpath = "//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath = "//input[contains(@id,'jobs') and contains(@aria-label,'skill')]")
    private WebElement jobSearchBar;

    @FindBy(xpath = "//input[contains(@id,'location') and contains(@aria-label,'City')]")
    private WebElement locationSearchBar;

    public TC002(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(40)); // Increased the wait time to 40 seconds
        PageFactory.initElements(driver, this);
    }

    // Method to click on the Job Module first
    public void job() {
        try {
            // Wait for the element to be visible and clickable
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            jobModule.click(); // Click the job module first
            Screenshots.takeScreenShot(driver, "Job module is clicked"); 
            System.out.println("Job Module clicked successfully.");
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    // Perform the negative test case after the job module is clicked
    public void performNegativeTest(String invalidJob, String invalidLocation) throws InterruptedException {
        Thread.sleep(2000);
    	
    	job();  // Ensure the job module is clicked first
        
        // Clear and fill in the job search bar using JavaScriptExecutor
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            wait.until(ExpectedConditions.visibilityOf(jobSearchBar));
            js.executeScript("arguments[0].value='';", jobSearchBar); // Clear the search bar
            jobSearchBar.sendKeys(invalidJob);
            Screenshots.takeScreenShot(driver, "Job role is entered"); // Input the invalid job value passed from the data provider
            System.out.println("Entered job search keyword: " + invalidJob);

            // Clear and fill in the location search bar
            wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
            locationSearchBar.clear(); // Clear the location field
            locationSearchBar.sendKeys(invalidLocation); // Input the invalid location value passed from the data provider
            Screenshots.takeScreenShot(driver, "Location is entered"); 
            System.out.println("Entered location keyword: " + invalidLocation);
            
            // Interact with the location field
            Actions actions = new Actions(driver);
            wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
            Thread.sleep(2000);  // Sleep to simulate user interaction
            actions.moveToElement(locationSearchBar).moveByOffset(50, 100).click().perform();
            Screenshots.takeScreenShot(driver, "Required location is clicked"); 
            Reporter.log("No jobs found for this role and location");

        } catch (Exception e) {
            System.out.println("Error while performing negative test case.");
            e.printStackTrace();
        }
    }
}
