package pages;

import org.openqa.selenium.WebDriver;
import utils.ExcelReader;
import utils.ExtentReportManager;
import utils.Screenshots;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class TC001 extends BasePage {

    private WebDriverWait wait;
    
//    private ExtentReportManager extentreportmanager = new ExtentReportManager();

    @FindBy(xpath="//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath = "//input[contains(@id,'jobs') and contains(@aria-label,'skill')]")
    private WebElement jobSearchBar;

    @FindBy(xpath = "//input[contains(@id,'location') and contains(@aria-label,'City')]")
    private WebElement locationSearchBar;
    
    @FindBy(xpath="//button[text()='Search']")
    private WebElement clicksearchbtn;
    
    String screenshots_test;

    public TC001(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    public void job() {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            Actions actions = new Actions(driver);
            actions.moveToElement(jobModule).click().perform();
//            extentreportmanager.ext_test = extentreportmanager.ext_reports.createTest("Job module","Entering to Job Module");
            screenshots_test = Screenshots.takeScreenShot(driver, "Job module is clicked"); 
//            extentreportmanager.ext_test.addScreenCaptureFromPath(screenshots_test);
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    public void enterjobloc() throws Exception {
        jobSearchBar.click();
        String jobrole=ExcelReader.getCellData("./src/test/resources/Exceldata/TC001.xlsx", "sheet1", 0, 0);
        jobSearchBar.sendKeys(jobrole);
        Screenshots.takeScreenShot(driver, "Job role is entered"); 
        locationSearchBar.click();
        locationSearchBar.clear();
        String location=ExcelReader.getCellData("./src/test/resources/Exceldata/TC001.xlsx", "sheet1", 0, 1);
        locationSearchBar.sendKeys(location);
        Screenshots.takeScreenShot(driver, "Location is entered"); 
        Actions actions = new Actions(driver);
        wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
        Thread.sleep(2000);
        actions.moveToElement(locationSearchBar).moveByOffset(50, 100).click().perform();
        Screenshots.takeScreenShot(driver, "Required location is clicked"); 
        actions.moveToElement(clicksearchbtn).click().perform();
        System.out.println("List of jobs are successfully displayed for given role and location");
    }
}