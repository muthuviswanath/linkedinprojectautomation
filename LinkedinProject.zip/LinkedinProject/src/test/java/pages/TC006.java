package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utils.Screenshots;

import java.time.Duration;

public class TC006 extends BasePage {

    private WebDriverWait wait;

    // Job module and Interview Prep elements
    @FindBy(xpath="//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath="//span[text()='Interview prep']")
    private WebElement interviewprep;
    @FindBy(xpath="/html[1]/body[1]/div[6]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[1]/ol[1]/li[2]/a[1]/div[1]/div[1]/p[1]/div[1]")
    private WebElement question1;

    @FindBy(xpath="//span[text()='Your answers']")
    private WebElement youranswer;

    @FindBy(xpath="//li[@class='interview-prep-answer-list-modal__answer artdeco-list__item']/div/button[2]")
    private WebElement deleteanswer;

    @FindBy(xpath="//button[@data-test-dialog-primary-btn]//span[text()='Delete']")
    private WebElement clickdelete;

    public TC006(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // Method to click the Job module first
    public void job() {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            jobModule.click();  // Click the Job module
            Screenshots.takeScreenShot(driver, "Clicked on job module"); 
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    // Method to delete an answer in Interview prep
    public void deleteAnswer() {
        job();  // Ensure job module is clicked first before interacting with interview prep
        try {
            wait.until(ExpectedConditions.visibilityOf(interviewprep));
            wait.until(ExpectedConditions.elementToBeClickable(interviewprep));
            Actions actions = new Actions(driver);
            actions.moveToElement(interviewprep).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on interviewPrep"); 
            Thread.sleep(2000);
            actions.moveToElement(question1).click().perform();
            Screenshots.takeScreenShot(driver, "Selected question"); 
            Thread.sleep(2000);
            actions.moveToElement(youranswer).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on answers"); 
            Thread.sleep(2000);
            actions.moveToElement(deleteanswer).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on delete"); 
            Thread.sleep(2000);
            actions.moveToElement(clickdelete).click().perform();
            Screenshots.takeScreenShot(driver, "Answer deleted"); 
            Thread.sleep(2000);
            Reporter.log("Your answer is successfully deleted");
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }
}
