package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utils.Screenshots;

import java.time.Duration;
import java.util.List;

public class TC003 extends BasePage {

    private WebDriverWait wait;

    // Job module, job search bar, and location search bar
    @FindBy(xpath="//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath = "//input[contains(@id,'jobs') and contains(@aria-label,'skill')]")
    private WebElement jobSearchBar;

    @FindBy(xpath = "//input[contains(@id,'location') and contains(@aria-label,'City')]")
    private WebElement locationSearchBar;
    
    @FindBy(xpath="//button[text()='Search']")
    private WebElement clicksearchbtn;

    

    // Job list and save button
    @FindBy(xpath="//div[contains(@class,'job-card-list')][1]//a")
    private List<WebElement> jobList;

    @FindBy(xpath="//div[contains(@class,'display-flex')]//div[contains(@class,'jobs-s-apply')]//following::button//span")
    private List<WebElement> save;

    public TC003(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // Method to click the Job module
    public void job() {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            jobModule.click();  // Click the Job module first
            Screenshots.takeScreenShot(driver, "Job module is clicked"); 
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    // Method to search for a location
    public void searchLocation() throws Exception {
        jobSearchBar.click();
        jobSearchBar.sendKeys("Software Engineer");
        Screenshots.takeScreenShot(driver, "Job role is entered"); 
        locationSearchBar.click();
        locationSearchBar.clear();
        locationSearchBar.sendKeys("Karnataka, Bengaluru");
        Screenshots.takeScreenShot(driver, "Location is entered"); 
        
        Actions actions = new Actions(driver);
        wait.until(ExpectedConditions.visibilityOf(locationSearchBar));
        Thread.sleep(2000);
        actions.moveToElement(locationSearchBar).moveByOffset(50, 100).click().perform();
        Screenshots.takeScreenShot(driver, "Required location is clicked"); 
        actions.moveToElement(clicksearchbtn).click().perform();
        Reporter.log("List of jobs displayed");
    }

    // Method to select a job from the job list and save it
    public void jobselectandsave() throws Exception {
        //job();  // Click the job module first
        //searchLocation();  // Search for a job and location
        
        // Wait for the job list to load and select the first job
        wait.until(ExpectedConditions.visibilityOfAllElements(jobList));
        Thread.sleep(4000);  // Adding some wait to ensure the list is fully loaded
        jobList.get(1).click();  // Select the second job in the list (index 1)
        Screenshots.takeScreenShot(driver, "Job is selected"); 
        Thread.sleep(4000);  // Wait for the job details to load
        
        // Save the job
        save.get(1).click();  // Click the 'Save' button for the job
        Screenshots.takeScreenShot(driver, "Job is saved or unsaved"); 
    }
}
