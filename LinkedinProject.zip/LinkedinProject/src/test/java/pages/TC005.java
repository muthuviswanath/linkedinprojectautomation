package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utils.Screenshots;

import java.time.Duration;

public class TC005 extends BasePage {

    private WebDriverWait wait;

    // Job module and Interview Prep elements
    @FindBy(xpath="//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath="//span[text()='Interview prep']")
    private WebElement interviewprep;

    @FindBy(xpath="/html[1]/body[1]/div[6]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[1]/ol[1]/li[2]/a[1]/div[1]/div[1]/p[1]/div[1]")
    private WebElement question1;

    @FindBy(xpath="//span[text()='Practice']")
    private WebElement practiceandgetfeedback;
    
//    @FindBy(xpath="//span[text()='Practice and get feedback']")
//    private WebElement practiceandgetfeedback;

    @FindBy(xpath="//span[text()='Write a response']")
    private WebElement writerepsonse;
    
   
    @FindBy(xpath="//textarea[@id='interview-prep-text-answer-modal__answer-input']")
    private WebElement answer;
    
//    @FindBy(xpath="//span[text()='Your answers']")
//    private WebElement answer;
    
    

    @FindBy(xpath="//span[text()='Save']")
    private WebElement saveanswer;

    public TC005(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // Method to click the Job module first
    public void job() {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            jobModule.click();  // Click the Job module
            Screenshots.takeScreenShot(driver, "Job module is clicked"); 
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    // Method to perform Interview Prep
    public void interviewPrep() {
        job();  // Ensure job module is clicked first before performing interview prep
        try {
            wait.until(ExpectedConditions.visibilityOf(interviewprep));
            wait.until(ExpectedConditions.elementToBeClickable(interviewprep));
            Actions actions = new Actions(driver);
            actions.moveToElement(interviewprep).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on InterviewPrep"); 
            Thread.sleep(2000);
            actions.moveToElement(question1).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on a question"); 
            Thread.sleep(2000);
            actions.moveToElement(practiceandgetfeedback).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on practice"); 
            Thread.sleep(2000);
            actions.moveToElement(writerepsonse).click().perform();
            Screenshots.takeScreenShot(driver, "Clicked on response"); 
            answer.click();
            answer.sendKeys("I am confident, adaptable, and a good problem solver.");
            Screenshots.takeScreenShot(driver, "Answer Typed"); 
            saveanswer.click();
            Screenshots.takeScreenShot(driver, "Answer saved"); 
            Thread.sleep(4000);
            Reporter.log("Your answer is successfully saved");
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }
}
