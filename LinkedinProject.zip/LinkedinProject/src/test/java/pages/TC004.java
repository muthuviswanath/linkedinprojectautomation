package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import utils.Screenshots;

import java.time.Duration;

public class TC004 extends BasePage {

    private WebDriverWait wait;

    // Job module and My Jobs elements
    @FindBy(xpath="//span[text()='Jobs']/ancestor::a")
    private WebElement jobModule;

    @FindBy(xpath="//span[text()='My jobs']")
    private WebElement myjobs;

    @FindBy(xpath="//button[text()='Saved']")
    private WebElement saved;
    
    public TC004(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // Method to click the Job module
    public void job() {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobModule));
            wait.until(ExpectedConditions.elementToBeClickable(jobModule));
            jobModule.click();  // Click the Job module first
            Screenshots.takeScreenShot(driver, "Job module is clicked"); 
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }

    // Method to click on the My Jobs section
    public void myJob() {
        job();  // Ensure job module is clicked before proceeding
        try {
            wait.until(ExpectedConditions.visibilityOf(myjobs));
            wait.until(ExpectedConditions.elementToBeClickable(myjobs));
            Actions actions = new Actions(driver);
            actions.moveToElement(myjobs).click().perform();
            Screenshots.takeScreenShot(driver, "MyJobs is clicked"); 
            actions.moveToElement(saved).click().perform();
            Screenshots.takeScreenShot(driver, "List of saved jobs displayed"); 
            Reporter.log("List of saved jobs are displayed");
            // Click My Jobs section
        } catch (Exception e) {
            System.out.println("Element not clickable using standard method.");
            e.printStackTrace();
        }
    }
}
