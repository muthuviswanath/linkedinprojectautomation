package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Screenshots;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.time.Duration;

public class LoginPage extends BasePage {

    private WebDriverWait wait;
    
    @FindBy(xpath = "//a[@class='nav__button-secondary btn-secondary-emphasis btn-md']")
    private WebElement signinButton;

    @FindBy(xpath = "/html[1]/body[1]/div[1]/main[1]/div[2]/div[1]/form[1]/div[1]/input[1]")
    private WebElement username;

    @FindBy(xpath = "//input[@id='password']")
    private WebElement password;

    @FindBy(xpath = "//button[@type='submit' and contains(text(), 'Sign in')]")
    private WebElement signin;

    private Properties properties;

    public LoginPage(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
        properties = loadProperties();  // Load properties on object creation
    }

    private Properties loadProperties() {
        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream("src/test/resources/PropertieData/profileData.properties")) {
            properties.load(input);
        } catch (IOException e) {
            System.err.println("Error loading properties file: " + e.getMessage());
        }
        return properties;
    }

    public void navigateToLoginPage() throws Exception {
        wait.until(ExpectedConditions.elementToBeClickable(signinButton)).click();
        Screenshots.takeScreenShot(driver, "Sign In button clicked"); 
        wait.until(ExpectedConditions.visibilityOf(username));
    }

    public void login() throws Exception {
        // Retrieve username and password from the properties file
        String user = properties.getProperty("username");
        String pass = properties.getProperty("password");
        
        wait.until(ExpectedConditions.visibilityOf(username)).sendKeys(user);
        Screenshots.takeScreenShot(driver, "Username is entered"); 
        wait.until(ExpectedConditions.visibilityOf(password)).sendKeys(pass);
        Screenshots.takeScreenShot(driver, "Password is entered"); 
    }

    public void clickbutton() throws Exception {
        wait.until(ExpectedConditions.elementToBeClickable(signin));
        signin.click();
        Screenshots.takeScreenShot(driver, "Signed in"); 
    }
}
