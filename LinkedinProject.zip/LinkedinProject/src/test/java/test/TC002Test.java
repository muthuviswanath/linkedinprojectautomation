package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.TC002;

import java.time.Duration;

public class TC002Test {

    private WebDriver driver;
    private WebDriverWait wait;
    private TC002 negativeTest; // Page object for TC002 (Negative test case)
    private LoginPage loginPage; // Page object for login

    @BeforeClass
    public void setup() {
        // Initialize the WebDriver, WebDriverWait, and Page Object classes
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
        wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // Increased wait time
        loginPage = new LoginPage(driver);

        // Initialize the page object for TC002 (Negative test case)
        negativeTest = new TC002(driver);
    }

    @BeforeMethod
    public void beforeEachTest() throws Exception {
        // Check if the user is already logged in, if not, log in
        if (!driver.getCurrentUrl().contains("linkedin.com/feed")) {
            driver.navigate().to("https://www.linkedin.com/");
            loginPage.navigateToLoginPage();
            loginPage.login();  // Log in using credentials from the properties file
            loginPage.clickbutton();  // Click on the sign-in button
        }
    }

    @DataProvider(name = "Invalidrole")
    public Object[][] Invalidrole() {
        return new Object[][] {
            { "Hell", "Karnataka ,Bengaluru" } // Invalid job and location for the negative test
        };
    }

    @Test(priority = 1, dataProvider = "Invalidrole")
    public void testNegativeJobSearchAndLocation(String invalidJob, String invalidLocation) throws InterruptedException {
        Reporter.log("Starting Negative Job Search Test with invalid inputs...");

        // Perform the negative test by entering invalid job and location inputs
        negativeTest.performNegativeTest(invalidJob, invalidLocation);  // Passing invalid job and location to the method

        Reporter.log("Performed negative test with invalid job: " + invalidJob + " and invalid location: " + invalidLocation);
    }

    @AfterMethod
    public void afterEachTest() {
        // Optionally, wait for a few seconds before proceeding with the next test case
        try {
            Reporter.log("Waiting for a few seconds before the next test case...");
            Thread.sleep(10000); // Wait for 10 seconds between test cases (can be adjusted)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().to("https://www.linkedin.com/");
    }

    @AfterClass
    public void teardown() {
        // Quit the driver session after all tests are completed
        driver.quit();
    }
}
