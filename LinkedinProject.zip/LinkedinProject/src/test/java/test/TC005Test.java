package test;

import driversetup.SetupDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.TC005;

import java.time.Duration;

public class TC005Test {

    private WebDriver driver;
    private WebDriverWait wait;
    private TC005 interviewPrepTest;
    private LoginPage loginPage;

    @BeforeClass
    public void setup() {
        // Initialize the WebDriver, WebDriverWait, and Page Object classes
        driver = SetupDriver.getDriver("chrome");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(40));  // Increased wait time
        interviewPrepTest = new TC005(driver);
        loginPage = new LoginPage(driver);
    }

    @BeforeMethod
    public void beforeEachTest() throws Exception {
        // Check if the user is already logged in, if not, log in
        if (!driver.getCurrentUrl().contains("linkedin.com/feed")) {
            driver.navigate().to("https://www.linkedin.com/");
            loginPage.navigateToLoginPage();
            loginPage.login();  // Log in using credentials from the properties file
            loginPage.clickbutton();  // Click on the sign-in button

            // Wait for successful login and ensure we are on the feed page (home feed)
            wait.until(ExpectedConditions.urlContains("linkedin.com/feed"));
        }
    }

    @Test(priority = 1)
    public void testInterviewPreparation() throws InterruptedException {
        // Perform the interview preparation actions
        interviewPrepTest.interviewPrep();

        // Optionally, you can add an assertion to verify that the "Interview prep" section is navigated
        // For example, checking for the visibility of a specific element or confirming URL
        // Assert.assertTrue(driver.getCurrentUrl().contains("interview-prep"));

        // Wait for a few seconds to observe the test behavior
        try {
            Thread.sleep(5000); // Sleep for a few seconds to observe the test execution
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void afterEachTest() {
        // Optionally, wait for a few seconds before proceeding with the next test case
        try {
            System.out.println("Waiting for a few seconds before the next test case...");
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterClass
    public void teardown() {
        // Quit the driver session after all tests are completed
        SetupDriver.quitDriver();
    }
}
