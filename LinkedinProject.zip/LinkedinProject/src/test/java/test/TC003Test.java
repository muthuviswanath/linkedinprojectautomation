package test;

import driversetup.SetupDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.TC003;

import java.time.Duration;

public class TC003Test {

    private WebDriver driver;
    private WebDriverWait wait;
    private TC003 jobTest;
    private LoginPage loginPage;

    @BeforeClass
    public void setup() {
        driver = SetupDriver.getDriver("chrome");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(40));  // Increased wait time
        jobTest = new TC003(driver);
        loginPage = new LoginPage(driver);
    }

    @BeforeMethod
    public void beforeEachTest() throws Exception {
        if (!driver.getCurrentUrl().contains("linkedin.com/feed")) {
            driver.navigate().to("https://www.linkedin.com/");
            loginPage.navigateToLoginPage();
            loginPage.login();  // Log in using credentials from the properties file
            loginPage.clickbutton();  // Click on the sign-in button

            // Wait for successful login and ensure we are on the feed page (home feed)
            wait.until(ExpectedConditions.urlContains("linkedin.com/feed"));
        }
    }

    @Test(priority = 1)
    public void testJobSearchAndSave() throws Exception {
        // Click on the job module and perform the job search
        jobTest.job();
        
        // Search for a job and location
        jobTest.searchLocation();
        
        // Select and save a job from the list
        jobTest.jobselectandsave();

        // Optionally add some assertions, e.g., checking if the job was saved correctly.
        // This will depend on LinkedIn's UI, e.g., checking the saved jobs section.

        try {
            Thread.sleep(5000); // Sleep for a few seconds to observe the test execution
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void afterEachTest() {
        // Wait for a few seconds before the next test case (can be adjusted as needed)
        try {
            System.out.println("Waiting for a few seconds before the next test case...");
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AfterClass
    public void teardown() {
        // Close the browser session after tests are completed
        SetupDriver.quitDriver();
    }
}
