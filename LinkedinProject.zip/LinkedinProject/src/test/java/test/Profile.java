package test;

import driversetup.SetupDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import pages.LoginPage;
import pages.TC001;
import pages.TC002;
import pages.TC003;
import pages.TC004;
import pages.TC005;
import pages.TC006;
import utils.ExtentReportManager;

import java.lang.reflect.Method;
import java.time.Duration;

public class Profile{

    private WebDriver driver;
    private WebDriverWait wait;
    private TC001 jobSearchTest;
    private TC002 negativeTest;
    private TC003 jobTest;
    private TC004 jobTestMyJobs;
    private TC005 interviewPrepTest;
    private TC006 deleteAnswerTest;
    private LoginPage loginPage;
 

    @BeforeClass
    public void setup() {
        // Initialize the WebDriver, WebDriverWait, and Page Object classes
    	   
    	
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
        wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // Increased wait time
        loginPage = new LoginPage(driver);

        // Initialize page object classes for all tests
        jobSearchTest = new TC001(driver);
        negativeTest = new TC002(driver);
        jobTest = new TC003(driver);
        jobTestMyJobs = new TC004(driver);
        interviewPrepTest = new TC005(driver);
        deleteAnswerTest = new TC006(driver);
        
    }

    @BeforeMethod
    public void beforeEachTest(Method methods) throws Exception {
        // Check if the user is already logged in, if not, log in
    	
        if (!driver.getCurrentUrl().contains("linkedin.com/feed")) {
            driver.navigate().to("https://www.linkedin.com/");
            loginPage.navigateToLoginPage();
            loginPage.login();  // Log in using credentials from the properties file
            loginPage.clickbutton();  // Click on the sign-in button

            // Wait for successful login and ensure we are on the feed page (home feed)
            wait.until(ExpectedConditions.urlContains("linkedin.com/feed"));
        }

        
    }
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:Searching list of jobs for valid role and location
     */
    
    
    

    @Test(priority = 1)
    public void testJobSearch() throws Exception {
        Reporter.log("Starting Job Search Test...");
        // Perform the job search functionality
        jobSearchTest.job(); 
        Reporter.log("Clicked on Job module.");
        Thread.sleep(2000); //Click the Job module
        jobSearchTest.enterjobloc();  // Enter the job and location
        Reporter.log("Entered job and location for search.");
        Thread.sleep(4000); // Sleep for a few seconds to observe the test execution
    }

    
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:Searching list of jobs for invalid role and location
     */
    
    
    
    @DataProvider(name = "Invalidrole")
    public Object[][] Invalidrole() {
        return new Object[][] { { "Hell", "Karnataka ,Bengaluru" } };
    }

  
    
    @Test(priority = 2, dataProvider = "Invalidrole", dependsOnMethods = "testJobSearch")
    public void testNegativeJobSearchAndLocation(String invalidJob, String invalidLocation) throws InterruptedException {
        Reporter.log("Starting Negative Job Search Test with invalid inputs...");
        // Perform the negative test by entering invalid job and location inputs
        Thread.sleep(5000);
        negativeTest.performNegativeTest(invalidJob, invalidLocation);  // Passing invalid job and location to the method
        Reporter.log("Performed negative test with invalid job: " + invalidJob + " and invalid location: " + invalidLocation);
        String errorMessage = driver.getPageSource(); // Get the page source
        Assert.assertFalse(errorMessage.contains("hello"), "The error message 'No matching jobs found' was displayed."); 
        Thread.sleep(5000); // Sleep for 5 seconds to allow observation of the test execution results
    }
    
    
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:Searching list of jobs for valid role and location and saving it.
     */

    @Test(priority = 3)
    public void testJobSearchAndSave() throws Exception {
        Reporter.log("Starting Job Search and Save Test...");
         //Click on the job module and perform the job search
        Thread.sleep(4000);
        jobTest.job();
        Reporter.log("Clicked on Job module.");
        Thread.sleep(4000);
         //Search for a job and location
        jobTest.searchLocation();
        Reporter.log("Entered search location.");
        Thread.sleep(4000);
        // Select and save a job from the list
        jobTest.jobselectandsave();
        Reporter.log("Selected and saved a job.");
        Thread.sleep(7000); // Sleep for a few seconds to observe the test execution
    }

    
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:Verifying saved job
     */
    
    @Test(priority = 4)
    public void testNavigateToMyJobs() throws InterruptedException {
        Reporter.log("Navigating to My Jobs...");
        // Click the job module and navigate to the "My Jobs" section
        Thread.sleep(2000);
        jobTestMyJobs.myJob();
        Reporter.log("Navigated to My Jobs section.");
        Thread.sleep(5000); // Sleep for a few seconds to observe the test execution
    }
    
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:Interview
     */

    @Test(priority = 5)
    public void testInterviewPreparation() throws InterruptedException {
        Reporter.log("Starting Interview Preparation Test...");
        // Perform the interview preparation actions
        interviewPrepTest.interviewPrep();
        Reporter.log("Performed interview preparation actions.");
        Thread.sleep(5000); // Sleep for a few seconds to observe the test execution
    }
    
    
    /***
     * Created By:Poornashree.S
     * Reviewed By:
     * Test Scenario:
     */

    @Test(priority = 6)
    public void testDeleteAnswer() throws InterruptedException {
        Reporter.log("Starting Delete Answer Test...");
        // Perform the delete answer actions
        deleteAnswerTest.deleteAnswer();
        Reporter.log("Performed delete answer actions.");
        Thread.sleep(5000); // Sleep for a few seconds to observe the test execution
    }

    @AfterMethod
    public void afterEachTest() {
        // Optionally, wait for a few seconds before proceeding with the next test case
        try {
            Reporter.log("Waiting for a few seconds before the next test case...");
            Thread.sleep(10000); // Wait for 10 seconds between test cases (can be adjusted)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().to("https://www.linkedin.com/");
    }

    @AfterClass
    public void teardown() {
        // Quit the driver session after all tests are completed
        SetupDriver.quitDriver();
    }
}

